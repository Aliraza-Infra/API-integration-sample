# Usage examples

## GitHub
Run `python examples/run_github_example.py` (no API key required for public endpoints).

## OpenAI
Set `OPENAI_API_KEY` env var and run `python examples/run_openai_example.py`.
